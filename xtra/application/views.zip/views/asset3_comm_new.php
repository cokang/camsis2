<body style="margin:0px;">
<table class="tftable" border="1" style="text-align:left;">
<?php if($this->input->get('MC') == '1') { ?>
	<tr>
		<th style="text-align:left;" colspan="2">Confirm New Request <i style="font-size:9px;">( File(s) not uploaded )</i></th>
	</tr>
	<tr>
		<td style="color:blue;" colspan="2">You have entered the information as shown below. <br /> To change your entry, click on [CHANGE] button at the bottom. <br /> To proceed creating this request, please click on [Save] button.</td>
	</tr>
	<tr>
		<th style="text-align:left;" colspan="2">Components Details</th>
	</tr>
	<tr>
		<td>Component Name</td>
		<td><?php echo $this->input->get('att_name');?></td>
	</tr>
	<?php if ($this->input->get('mrin') != 'update'){ ?>
	<tr>
		<td>Picture File</td>
		<td><?php echo $this->input->get('image_file');?></td>
	</tr>
	<?php } ?>
	<tr>
		<td colspan="2"><button type="button" value="Change" onclick="location.href = '<?php echo base_url();?>index.php/Procurement/asset3_comm_new?id=<?php echo $this->input->get('id')?>&act=<?php echo $this->input->get('act')?>&mrin=<?php echo $this->input->get('mrin')?>&name=<?php echo $this->input->get('att_name')?>';" >Change</button> <input type="submit" value="Add" onClick="javascript:showmg('<?php echo $this->input->get('id');?>','<?php echo $this->input->get('att_name');?>','<?php echo $this->input->get('image_file');?>');"> </td>
	</tr>
<?php }else{ ?>
	<tr>
		<th style="text-align:left;">New MRIN Component</th>
	</tr>
	<tr>
		<td>Attachment for temp38145</td>
	</tr>
	<tr>
		<td>File attachment must be less then 1MB  </td>
	</tr>
	<tr>
		<th style="text-align:left;">Components Details</th>
	</tr>
	<form enctype="multipart/form-data" action="" method="post" id="form">
	<tr>
		<td>Attachment Name : <input type="text" value="<?= ($this->input->get('name')) ? $this->input->get('name') : ''?>" name="att_name" id="att_name"> </td>
	</tr>
	<?php if ($this->input->get('mrin') != 'update'){ ?>
	<tr>
		<td>Select a file to upload: <input type="file" id="image-file" value="<?php echo set_value('image-file'); ?>" name="image-file" id="image-file"> </td>
	</tr>
	<?php } ?>
	<tr>
		<td>
		<button type="reset" value="Clear All">Clear All</button> 
		<input type="submit" value="Save" onClick="if(verifyFile()){document.fileUpForm.submit();}">
		<button type="cancel"  onclick="window.parent.close();">Cancel</button> </td>
	</tr>
		</form>
<?php } ?>

</table>
<script type="text/javascript">
<?php if ($this->input->get('mrin') != 'update'){ ?>
    function verifyFile()
	{
	if(document.getElementById("image-file").value == "") {
	alert("Must choose a file first!");
	return false;
	}
	if(document.getElementById("image-file").value.length < 5) {
	alert("Invalid filename. Must contain proper extension.");
	return false;
	}
	att_name = document.getElementById("att_name").value ;
	image_file = document.getElementById("image-file").value ;
	if (image_file) {
    var startIndex = (image_file.indexOf('\\') >= 0 ? image_file.lastIndexOf('\\') : image_file.lastIndexOf('/'));
    var filename = image_file.substring(startIndex);
    if (filename.indexOf('\\') === 0 || filename.indexOf('/') === 0) {
        filename = filename.substring(1);
    }
	}
	document.getElementById("form").action = "asset3_comm_new?id=<?php echo $this->input->get('id')?>&act=<?php echo $this->input->get('act')?>&MC=1&att_name="+att_name+"&image_file="+filename;
	return true;
	}
<?php }else{ ?>
function verifyFile()
	{
	att_name = document.getElementById("att_name").value ;
	document.getElementById("form").action = "asset3_comm_new?id=<?php echo $this->input->get('id')?>&act=<?php echo $this->input->get('act')?>&MC=1&mrin=<?php echo $this->input->get('mrin')?>&att_name="+att_name;
	return true;
	}
<?php } ?>
	function showmg(tempw, tempwa, tempb){
        if (window.opener != null && !window.opener.closed) {
			window.opener.document.getElementById('n_agent').innerHTML = tempwa;
			var link = window.opener.document.getElementById("n_agent2");
			link.setAttribute('onclick', "fCallLocatioa('"+tempw+"','"+tempwa+"','"+tempb+"');");
			window.opener.document.getElementById("display").style.display = "block";
        }
        window.close();
		}

</script>
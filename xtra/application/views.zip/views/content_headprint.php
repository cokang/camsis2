<table border="0" width="100%" cellpadding="0" cellspacing="0" style="border-collapse: collapse" bordercolor="#111111">
	<tr>
		<td width="64"><img src="<?php echo base_url(); ?>images/penmedic2.png" class="imgpenmedic"/></td>
		<td style="padding-left:5%;" colspan="5">
			<!--<span class="PantaiCorporateName">Advance Pact Sdn Bhd</span>
			<span class="PantaiCompanyNo">(412168-V)</span>
			<br>
			<span class="ReportCenter">Site: <?= ($records[0]->v_HospitalName) ? $records[0]->v_HospitalName : 'NA' ?></span>--></td>
		<td width="64"><img src="<?php echo base_url(); ?>images/logo.png" class="imglogoap"/></td>
	</tr>
</table>
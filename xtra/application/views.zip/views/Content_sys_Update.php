<?php echo form_open('contentcontroller/sys_admin?gbl=3');?>
<?php $numberdate = 0; ?>
<div class="ui-middle-screen">
	<div class="content-workorder">
		<div class="div-p">&nbsp;</div>
		<div class="ui-main-form" style="background:#fff;">
			<div class="ui-main-form-header" style="background:#79B6D8;">
				<table align="left" height="40px" border="0">
					<tr>
						<td><span style="margin-left:10px;"><?php if ($this->input->get('sys_id') == ''){echo 'Add';}else{echo 'Edit';}?> Personal </span></td>
					</tr>
				</table>
			</div>
			<div class="ui-main-form-1">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Personal Code:</td>
											<td><input type="text" id="n_p_code" name="n_p_code"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Personal Name:</td>
											<td valign="top"><input type="text" id="n_p_Name" name="n_p_Name"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
										<td style="padding-left:10px; padding-top:5px;" valign="top">Labour Grade</td>
										<td valign="top"><input type="text" id="n_l_Grade" name="n_l_Grade" value="" class="form-control-button2 n_wi-eq3" readonly> <span class="icon-windows" onclick="fLabour(this)" value="Labour" ></span></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Hourly Rate :  </td>
											<td><input type="text" id="n_h_rate" name="n_h_rate"  value="" class="form-control-button2 n_wi-date2" readonly></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Base Location : </td>
											<td><input type="text" id="n_b_location" name="n_b_location"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Service Code : </td>
											<td>
											<?php $Service_list = array(
															'0' => 'CLS',
															'1' => 'CWMS',
															'2' => 'FEMS',
															'3' => 'LLS',
															'4' => 'BEMS'
														 ); ?>
								        <?php echo form_dropdown('n_s_Code', $Service_list, set_value('n_s_Code') , 'class="dropdown n_wi-date2"'); ?> </td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Service Description : </td>
											<td><input type="text" id="n_s_Description" name="n_s_Description"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Calender No  : </td>
											<td><input type="text" id="n_c_Calender" name="n_c_Calender"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>											
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<div class="ui-main-form-2">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Date Start:</td>
											<td><input type="text"  id="date<?php echo $numberdate++; ?>" name="n_d_Start"  value="" class="form-control-button2 n_wi-date2">
											</td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Date End  :   </td>
											<td valign="top"><input type="text"  id="date<?php echo $numberdate++; ?>" name="n_d_End"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
										<td style="padding-left:10px;" valign="top">Access Status</td>
										<td valign="top"><input type="text" id="n_a_Status" name="n_a_Status"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Hospital Code :  </td>
											<td valign="top"><input type="text" id="n_h_Code" name="n_h_Code"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Designation : </td>
											<td><input type="text" id="n_Designation" name="n_Designation"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Previous Location : </td>
											<td><input type="text" id="n_p_Location" name="n_p_Location"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Active Status  : </td>
											<td><input type="text" id="n_ac_Status" name="n_ac_Status"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Calender No  : </td>
											<td><input type="text" id="n_c_No" name="n_c_No"  value="" class="form-control-button2 n_wi-date2"></td>
										</tr>											
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<table align="center" height="40px" border="0" style="width:100%;" class="ui-main-form-footer">
				<tr>
					<td align="center">
					<input type="submit" class="btn-button btn-primary-button" style="width: 200px;" name="mysubmit" value="Save"> 
					<input type="button" class="btn-button btn-primary-button" style="width: 200px;" onclick="window.history.back()" name="Cancel" value="Cancel">
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>
<?php include 'content_jv_popup.php';?>
</body>
<?php echo form_close(); ?>
</html>

<body>
	<button type="cancel" class="btn-button btn-primary-button" onclick="window.history.back()" style="width:10%;">Back</button>
	<div class="header_report_main"> MONTHLY PPM PERFORMANCE REPORT</div>
	<div class="middle_report_main">
		<table class="middle_report_tbl">
			<tr>
				<th colspan="27" class="middle_report_tbl_tr">PPM</th>
			</tr>
			<tr>
				<th>Services</th>
				<th colspan="3">8 Months</th>
				<th colspan="3">7 Months</th>
				<th colspan="3">6 Months</th>
				<th colspan="3">5 Months</th>
				<th colspan="3">4 Months</th>
				<th colspan="3">3 Months</th>
				<th colspan="3">2 Months</th>
				<th colspan="4">1 Months as of 11/03/15</th>
				<th>Performance Index</th>
			</tr>
			<tr>
				<th></th>
				<th>before</th>
				<th>closed</th>
				<th>after</th>
				<th>before</th>
				<th>closed</th>
				<th>after</th>
				<th>before</th>
				<th>closed</th>
				<th>after</th>
				<th>before</th>
				<th>closed</th>
				<th>after</th>
				<th>before</th>
				<th>closed</th>
				<th>after</th>
				<th>before</th>
				<th>closed</th>
				<th>after</th>
				<th>before</th>
				<th>closed</th>
				<th>after</th>
				<th>before</th>
				<th>add</th>
				<th>closed</th>
				<th>after</th>
				<th></th>
			</tr>
			<tr><td>BES</td><td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&sta=c&h=BPH">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&h=BPH">0</a></td>
					<td>4</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&sta=c&h=BPH">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&h=BPH">4</a></td>
					<td>3</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&sta=c&h=BPH">1</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&h=BPH">2</a></td>
					<td>7</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&sta=c&h=BPH">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&h=BPH">7</a></td>
					<td>8</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&sta=c&h=BPH">1</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&h=BPH">7</a></td>
					<td>10</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&sta=c&h=BPH">1</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&h=BPH">9</a></td>
					<td>20</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&sta=c&h=BPH">2</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&h=BPH">18</a></td>
					<td>7(59)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=add&h=BPH">43</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=c&h=BPH">32</a>(37)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&h=BPH">18</a></td>
					<!--<td>65</td>-->
					
					<td>10.17</td></tr>
					

					<!--<td>43-37/59</td></tr>-->
					
					

<tr class="alt"><td>FES<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&sta=c&h=HSA">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&h=HSA">0</a></td>
					<td>2</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&sta=c&h=HSA">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&h=HSA">2</a></td>
					<td>11</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&sta=c&h=HSA">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&h=HSA">11</a></td>
					<td>11</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&sta=c&h=HSA">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&h=HSA">11</a></td>
					<td>16</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&sta=c&h=HSA">2</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&h=HSA">14</a></td>
					<td>40</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&sta=c&h=HSA">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&h=HSA">40</a></td>
					<td>69</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&sta=c&h=HSA">3</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&h=HSA">66</a></td>
					<td>28(177)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=add&h=HSA">83</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=c&h=HSA">39</a>(44)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&h=HSA">72</a></td>
					<!--<td>216</td>-->
					
					
					<td>22.03</td></tr>
					

					<!--<td>83-44/177</td></tr>-->
 
<tr><td>HKS</td><td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&sta=c&h=HSI">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&h=HSI">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&sta=c&h=HSI">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&h=HSI">0</a></td>
					<td>3</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&sta=c&h=HSI">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&h=HSI">3</a></td>
					<td>11</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&sta=c&h=HSI">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&h=HSI">11</a></td>
					<td>4</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&sta=c&h=HSI">1</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&h=HSI">3</a></td>
					<td>12</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&sta=c&h=HSI">2</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&h=HSI">10</a></td>
					<td>38</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&sta=c&h=HSI">1</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&h=HSI">37</a></td>
					<td>23(91)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=add&h=HSI">53</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=c&h=HSI">29</a>(33)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&h=HSI">47</a></td>
					<!--<td>111</td>-->
					
					<td>21.98</td></tr>
					

					<!--<td>53-33/91</td></tr>-->
					
					

<tr class="alt"><td>CWA<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&sta=c&h=KTG">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&h=KTG">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&sta=c&h=KTG">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&h=KTG">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&sta=c&h=KTG">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&h=KTG">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&sta=c&h=KTG">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&h=KTG">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&sta=c&h=KTG">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&h=KTG">0</a></td>
					<td>3</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&sta=c&h=KTG">2</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&h=KTG">1</a></td>
					<td>2</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&sta=c&h=KTG">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&h=KTG">2</a></td>
					<td>2(7)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=add&h=KTG">5</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=c&h=KTG">2</a>(4)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&h=KTG">5</a></td>
					<!--<td>8</td>-->
					
					
					<td>14.29</td></tr>
					

					<!--<td>5-4/7</td></tr>-->
 
<tr><td>SEC</td><td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&sta=c&h=KUL">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=8&h=KUL">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&sta=c&h=KUL">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=7&h=KUL">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&sta=c&h=KUL">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=6&h=KUL">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&sta=c&h=KUL">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=5&h=KUL">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&sta=c&h=KUL">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=4&h=KUL">0</a></td>
					<td>0</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&sta=c&h=KUL">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=3&h=KUL">0</a></td>
					<td>1</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&sta=c&h=KUL">0</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=2&h=KUL">1</a></td>
					<td>0(1)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=add&h=KUL">6</a></td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&sta=c&h=KUL">3</a>(3)</td><td><a href="reportbi-worcmwrty-listing-dev.asp?m=1&h=KUL">3</a></td>
					<!--<td>4</td>-->
					
					<td>300.00</td></tr>
					

					

<tr  style="background:#F7F2E0;"><td>Grand Total</td><td>8</td><td>2</td><td>6</td>
					<td>23</td><td>7</td><td>16</td>
					<td>50</td><td>4</td><td>46</td>
					<td>70</td><td>6</td><td>64</td>
					<td>75</td><td>9</td><td>66</td>
					<td>139</td><td>16</td><td>123</td>
					<td>307</td><td>51</td><td>256</td>
					<td>120(792)</td><td>641</td><td>491(586)</td><td>270</td>
					<!--<td>847</td>-->
					<td>6.94</td></tr>

		</table>
	</div>
</body>
<html>
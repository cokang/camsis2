<div class="ui-middle-screen">
	<div class="content-workorder">
	<?php if($this->input->get('rs') == 1){?>
	<div style="margin:10px;"></div>
	<?php } ?>
	
		<div class="ui-main-report">
			<div class="ui-main-report-header">
				<table align="center" height="40px" border="0" class="report_selection">
					<tr>
						<td>Selection</td>
					</tr>
				</table>
			</div>
			<form action="" method="POST" name="myform">
			<div class="middle-report-3">
				Search By Location : <input type="text" name="n_loc" id="n_user_department1" value="" class="form-control-button2"> 
				<input type="text" name="n_loc" id="n_location" value="" class="form-control-button2"> <span class="icon-windows" onclick="fCalllocation('2',this)">
			</div>
			<div  class="middle-report-3">
				<input type="radio" id="radio-1-1" name="n_wotype" class="regular-radio" value = "Request"/>   
				<label for="radio-1-1"></label> Request <br />
				<input type="radio" id="radio-1-2" name="n_wotype" class="regular-radio" value = "Complaint"/>   
				<label for="radio-1-2"></label> Complaint <br /> 
				<input type="hidden" name="data_file" value="Y">
				<input type="submit" class="btn btn-primary btn-block buttoncss" name="mysubmit" value="GO">
				<input type="submit" class="btn btn-primary btn-block buttoncss" name="myclear" value="CLEAR">
			</div>
			</form>
			<div class="middle-report-4">
				<table class="tftabledetail" border="0" style="text-align:center;">
					<tr>	
						<th>No</th>
						<th>Requestor</th>
						<th>Date</th>
						<th>Time</th>
						<th>Work Order</th>
						<th>Summary</th>
					</tr>
					<tr>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
					</tr>
					
				</table>
				<table class="tftabledetail" border="0" style="text-align:center;">
					<tr>	
						<td style="color:red; text-align:center; height:50px;" colspan="4">Result: No matching record found.</th>
					</tr>
				</table>
				</form>
			</div>
		</div>
	</div>
</div>
<script>
	//$(document).ready(function(){
	//	$("#GO").click(function(){
	//		$("#loginTable").show();
	//	});
	//	$("#Clear").click(function(){
	//		$("#loginTable").hide();
	//	});
	//});
    // $(document).ready(function(){
    //$('.check:button').toggle(function(){
    //    $('input:checkbox').attr('checked','checked');
    //    $(this).val('Deselect all')
    //},function(){
    //    $('input:checkbox').removeAttr('checked');
    //    $(this).val('Select All');        
    //})
	//})
   </script>
</div>
</body>
</html>
<?php include 'content_jv_popup.php';?>
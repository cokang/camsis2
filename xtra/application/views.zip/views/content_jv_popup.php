<?php if ('contentcontroller/sys_admin/' == $this->uri->slash_segment(1) .$this->uri->slash_segment(2)){ ?>
    <?php if ($this->input->get('gbl') == 2){?>
 <script>
 function fLabour(a)
		{
			//var parent = a.getAttribute('value');
			winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_syslabour";
		
	}
	else {
		echo "contentcontroller/pop_syslabour";
		
	}?>', '', winProp);
			Win.window.focus();
		}
</script>
	<?php }elseif($this->input->get('ec') == 2){ ?>
	 <script>
 function fsystemcode(a){
//var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_systemcode";
		
	}
	else {
		echo "contentcontroller/pop_systemcode";
		
	}?>', '', winProp);
			Win.window.focus();
		}
function fchecklist(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_checklist";
		
	}
	else {
		echo "contentcontroller/pop_checklist";
		
	}?>?id='+parent+'', '', winProp);
			Win.window.focus();
		}
function fWorkgroup(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_fWorkgroup";
		
	}
	else {
		echo "contentcontroller/pop_fWorkgroup";
		
	}?>?id='+parent+'', '', winProp);
			Win.window.focus();
		}
		
</script>
<?php }elseif($this->input->get('jt') == 2){ ?>
<script>
function fchecklist(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_checklist";
		
	}
	else {
		echo "contentcontroller/pop_checklist";
		
	}?>?id='+parent+'', '', winProp);
			Win.window.focus();
		}
function fEquipment(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_fEquipment";
		
	}
	else {
		echo "contentcontroller/pop_fEquipment";
		
	}?>?id='+parent+'', '', winProp);
			Win.window.focus();
		}
function fType(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_fType";
		
	}
	else {
		echo "contentcontroller/pop_fType";
		
	}?>?id='+parent+'', '', winProp);
			Win.window.focus();
		}
function fProcedure(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_fProcedure";
		
	}
	else {
		echo "contentcontroller/pop_fProcedure";
		
	}?>?id='+parent+'', '', winProp);
			Win.window.focus();
		}
</script>

	<?php } ?>
<?php }elseif($this->uri->slash_segment(2) == 'updatecommissioning/'){ ?>	
<script>
function fRequest12(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_fRequest12";
		
	}
	else {
		echo "contentcontroller/pop_fRequest12";
		
	}?>', '', winProp);
			Win.window.focus();
		}
</script>
<?php }elseif($this->uri->slash_segment(2) == 'fail_bank/'){ ?>	
<script>
function fbank(a,b){
//var parent = a.getAttribute('value');
//var docid = b.getAttribute('value');
winProp = 'width=500,height=100,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_fail";
		
	}
	else {
		echo "contentcontroller/pop_fail";
		
	}?>?assetno='+a+'&docid='+b+'', '', winProp);
			Win.window.focus();
		}
</script>
<?php }elseif($this->uri->slash_segment(1) == 'Procurement/'){ ?>
		<?php if(($this->input->get('pro') == 'new') or ($this->input->get('pr') == 'pending')){ ?>
<script>
function fCallRequestA(){
	var assno = document.getElementById("n_assetnumber");
	winProp = 'width=' + screen.width + ',height=' + screen.height + ',left=,top=,menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
		if (assno.value != ''){
		Win = window.open("<?php if ($this->uri->slash_segment(1) == 'contentcontroller/') { echo "assetupdate";} else { echo "contentcontroller/assetupdate"; }?>?asstno="+assno.value , "AssetDetails", winProp);
		Win.window.focus();
		} else {
		alert('Please Choose Workorder..');
		}
}
function pop_requests(a){
	var value = a.getAttribute('value');
	winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('<?php if ($this->uri->slash_segment(1) == 'contentcontroller/') { echo "pop_requests"; } else { echo "contentcontroller/pop_requests"; }?>?p='+value, 'assetnumber', winProp);
	Win.window.focus();
}
function fCallLocationa(mirnno){
	winProp = 'width=450,height=270,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('<?php if ($this->uri->slash_segment(2) != 'e_pr/') { echo "Procurement/asset3_comm_new";} else { echo "asset3_comm_new"; }?>?id=' + mirnno + '&act=addnew', 'Location', winProp);
	Win.window.focus();
	}
function fCallLocatioa(mirnno,tempwa,tempwb){
	winProp = 'width=450,height=270,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('<?php if ($this->uri->slash_segment(2) != 'e_pr/') { echo "Procurement/asset3_comm_new";} else { echo "asset3_comm_new"; }?>?id=' + mirnno + '&act=addnew&mrin=update&name=' + tempwa + '&pic=' + tempwb, 'Location', winProp);
	Win.window.focus();
	}
</script>
<?php }elseif(($this->input->get('po') == 'update') and ($this->input->get('pr') == 'pen')){ ?>
<script>
function fCalldetailname(a)
		{
			var parent = a.getAttribute('value');
			//var hour = hour;
			//var minute = minute;
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'Procurement/') {
	echo "assetdetailname";
		
	}
	else {
		echo "contentcontroller/assetdetailname";
		
	}?>?pr='+parent, 'assetdetailname', winProp);
			Win.window.focus();
		}
</script>
		<?php } ?>		
<?php }else{ ?>
<script>
function fchecklist(a){
var parent = a.getAttribute('value');
winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_checklist";
		
	}
	else {
		echo "contentcontroller/pop_checklist";
		
	}?>?id='+parent+'', '', winProp);
			Win.window.focus();
		}
function fCallVendor()
		{
			winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('contentcontroller/E_Code', 'Vendor', winProp);
			Win.window.focus();
		}
function fCalllocation(value,object = false)
		{
		//alert(value);
			winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "location";
		
	}
	else {
		echo "contentcontroller/location";
		
	}?>?parent='+value, 'location', winProp);
			Win.window.focus();
		}
function rel()
		{
			var span_Text = document.getElementById("n_location").value;
			winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "relworkorder";
		
	}
	else {
		echo "contentcontroller/relworkorder";
		
	}?>?loc='+span_Text, 'location', winProp);
			Win.window.focus();
			
		}
function fCalltc_r_number()
		{
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('contentcontroller/tc_r_number', 'tc_r_number', winProp);
			Win.window.focus();
		}
function fCallpop_vendor(a)
		{
			var parent = a.getAttribute('value');
			winProp = 'width=1200,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_vendor";
		
	}
	else {
		echo "contentcontroller/pop_vendor";
		
	}?>?parent='+parent+'', 'location', winProp);
			Win.window.focus();
		}
function fCallpop_vendor2()
{
	winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('pop_vendor', 'pop_vendor', winProp);
	Win.window.focus();
}
function fCalldetailname(a,hour,minute)
		{
			var parent = a.getAttribute('value');
			//var hour = hour;
			//var minute = minute;
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "assetdetailname";
		
	}
	else {
		echo "contentcontroller/assetdetailname";
		
	}?>?parent='+parent+'&hour='+hour+'&minute='+minute, 'assetdetailname', winProp);
			Win.window.focus();
		}
		function fCallassetdetailname(a)
		{
			var parent = a.getAttribute('value');
			//var hour = hour;
			//var minute = minute;
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			//alert('nilai <?=$this->uri->slash_segment(1).' dan '.$this->uri->slash_segment(2)?>');
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "assetdetailname";
		
	}elseif (($this->uri->slash_segment(1) != 'contentcontroller/') && ($this->uri->slash_segment(2) != '/')){
	echo "../contentcontroller/assetdetailname";
	}
	else {
		echo "contentcontroller/assetdetailname";
		
	}
	?>?parent='+parent, 'assetdetailname', winProp);
			Win.window.focus();
		}
function fCallR_number()
		{
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('contentcontroller/R_number', 'R_number', winProp);
			Win.window.focus();
		}
function fCallassetsnumber(a)
		{
			var parent = a.getAttribute('value');
			winProp = 'width=1200,height=500,left=' + ((screen.width - 1200) / 2) +',top=' + ((screen.height - 600) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "assetnumber";
		
	}
	else {
		echo "contentcontroller/assetnumber";
		
	}?>?parent='+parent, 'assetnumber', winProp);
			Win.window.focus();
		}
function flink(m,y)
		{
			//var parent = a.getAttribute('value');
			//var month = m.getAttribute('value');
			//var year = y.getAttribute('value');
			winProp = 'width=1200,height=500,left=' + ((screen.width - 1200) / 2) +',top=' + ((screen.height - 600) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_link";
		
	}
	else {
		echo "contentcontroller/pop_link";
		
	}?>?m='+m+'&y='+y, 'assetnumber', winProp);
			Win.window.focus();
		}
function fCallIdentification_Type()
		{
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('Identification_Type', 'assetnumber', winProp);
			Win.window.focus();
		}
function fCallpop_Agency_Code()
		{
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('pop_Agency_Code', 'assetnumber', winProp);
			Win.window.focus();
		}
function fCallpop_Job_Type()
		{
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('pop_Job_Type', 'assetnumber', winProp);
			Win.window.focus();
		}
function fCallpop_Checklist_Code()
		{
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('pop_Checklist_Code', 'assetnumber', winProp);
			Win.window.focus();
		}

function fpop_location_user()
{
	winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_location_user";
		
	}
	else {
		echo "contentcontroller/pop_location_user";
		
	}?>', 'assetnumber', winProp);
	Win.window.focus();
}
function pecodes()
{
	winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pecodes";
		
	}
	else {
		echo "contentcontroller/pecodes";
		
	}?>?hosp=MKA', 'assetnumber', winProp);//change hosp to session
	Win.window.focus();
}
function pecodes2()
{
	var assno = document.getElementById("n_agent");

			if (assno.value != '')
				{
	winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pecodes2";
		
	}
	else {
		echo "contentcontroller/pecodes2";
		
	}?>?ic='+assno.value , 'assetnumber', winProp);
	Win.window.focus();
	}
				else
				{
				alert('Please Choose Equipment First..');
				}

}
function pop_requests(a)
{
var value = a.getAttribute('value');
	winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
	Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_requests";
		
	}
	else {
		echo "contentcontroller/pop_requests";
		
	}?>?p='+value, 'assetnumber', winProp);
	Win.window.focus();
}
function Schduler(a)
		{
			var assno = a.getAttribute('value');
			winProp = 'width=1300,height=600,left=' + ((screen.width - 1300) / 2) +',top=' + ((screen.height - 700) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "p_Schduler";
		
	}
	else {
		echo "contentcontroller/p_Schduler";
		
	}?>?loct='+assno, 'location', winProp);
			Win.window.focus();
		}

	function popauthority()
		{
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "pop_authority";
		
	}
	else {
		echo "contentcontroller/pop_authority";
		
	}?>', '', winProp);
			Win.window.focus();
		}
function fCallRequestA()
		{
			var assno = document.getElementById("n_assetnumber");
			winProp = 'width=' + screen.width + ',height=' + screen.height + ',left=,top=,menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
				if (assno.value != '')
				{
				Win = window.open("<?php 
if ($this->uri->slash_segment(1) == 'contentcontroller/') {
	echo "assetupdate";
		
	}
	else {
		echo "contentcontroller/assetupdate";
		
	}?>?asstno="+assno.value , "AssetDetails", winProp);
				Win.window.focus();
				}
				else
				{
				alert('Please Choose Workorder..');
				}
}
</script>
<?php } ?>
<div class="ui-middle-screen">
	<div class="content-workorder" style="padding-bottom:4%;">
		<table class="ui-content-middle-menu-workorder" border="0" width="90%" align="center" style="font-size:16px;">
			<tr class="ui-color-style-2" style="height:40px;">
				<td align="center" colspan="4" style="border-top-left-radius:10px; border-top-right-radius:10px;"><h4 class="h4-margin">Confirm New Request</h4></td>
			</tr>
			<form>
				<tr class="ui-color-contents-style-1">
					<td style="padding-left:10px; padding-bottom:20px; padding-top:10px; color:red;" colspan="4"></td>
				</tr>
				<tr class="ui-color-contents-style-1">
					<td style="padding-left:0px; margin-top:-2px;" width="57%" colspan="2" valign="top">
						<table width="98%" class="ui-content-middle-menu-workorder" style="">
							<tr class="ui-color-contents-style-1" height="30px">
								<td colspan="2" class="ui-header-new"><b>Request Details</b></td>
							</tr>
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Request Type:</td>
											<td style="padding-left:10px; padding-top:5px;"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Request Date :   </td>
											<td style="padding-left:10px;" valign="top"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Priority :  </td>
											<td style="padding-left:10px;" valign="top"></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Summary : </td>
											<td style="padding-left:10px;"><textarea class="InputText" name="" cols="22" rows="7" disabled></textarea></td>
										</tr>																																			
									</table>
								</td>
							</tr>
							<tr class="ui-color-contents-style-1">
								<td height="10px" colspan="4">&nbsp;</td>
							</tr>
							<tr class="ui-color-contents-style-1">
								<td style="padding-left:0px; margin-top:-2px;" width="100%" colspan="4" valign="top">
									<table width="99%" class="ui-content-middle-menu-workorder" style="">
										<tr style="color:white;" height="30px">
											<td colspan="2" class="ui-header-new"><b>Related Asset (Compulsory For Request A3 - A10)</b></td>
										</tr>
										<tr >
											<td class="ui-desk-style-table">
												<table class="ui-content-form" style="color:black;" width="100%" border="0">
													<tr>
														<td style="padding-left:10px;" width="50%">Asset Number :   </td>
														<td style="padding-left:10px;" width="50%"></td>
													</tr>
													<tr>
														<td style="padding-left:10px;">Tag Number :   </td>
														<td style="padding-left:10px;"></td>
													</tr>
													<tr>
														<td style="padding-left:10px;">Serial Number :  </td>
														<td style="padding-left:10px;"></td>
													</tr>
													<tr>
														<td style="padding-left:10px;">Name :	 </td>
														<td style="padding-left:10px;"></td>
													</tr>																																																																	
												</table>
											</td>
										</tr>						
									</table>
								</td>			
							</tr>
						</table>
					</td>
					<td style="padding-left:0px; margin-top:-2px;" width="43%" colspan="2" valign="top">
						<table width="98%" class="ui-content-middle-menu-workorder" style="">
							<tr class="ui-color-contents-style-1" height="30px">
								<td colspan="2" class="ui-header-new"><b>Details of Related Request</b></td>
							</tr>
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
																				<tr>
											<td style="padding-left:10px;">Requested By : </td>
											<td style="padding-left:10px;"><input type="text" name="FirstName" value=""></td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">Requested Date : </td>
											<td style="padding-left:10px; padding-top:5px;" valign="top"></td>
										</tr>																																									
									</table>
								</td>
							</tr>
							<tr class="ui-color-contents-style-1">
								<td height="20px" colspan="4">&nbsp;</td>
							</tr>
							<tr style="color:black;">
								<td style="padding-left:0px; margin-top:-2px;" width="100%" colspan="4" valign="top">
									<table width="99%" class="ui-content-middle-menu-workorder" style="">
										<tr class="ui-color-contents-style-1" height="30px">
											<td colspan="2" class="ui-header-new"><b>Location</b></td>
										</tr>
										<tr >
											<td class="ui-desk-style-table" style="padding-bottom: 8px;">
												<table class="ui-content-form" width="100%" border="0">
													<tr>
														<td style="padding-left:10px;" width="25%">Phone Number :  </td>
														<td style="padding-left:10px;" width="25%"></td>
													</tr>
													<tr>
														<td style="padding-left:10px;">User Department :   </td>
														<td style="padding-left:10px;"></td>
													</tr>
													<tr>
														<td style="padding-left:10px;">&nbsp; </td>
														<td style="padding-left:10px;"></td>
													</tr>
													<tr>
														<td style="padding-left:10px;">Location : </td>
														<td style="padding-left:10px;"></td>
													</tr>
													<tr>
														<td style="padding-left:10px;">&nbsp; </td>
														<td style="padding-left:10px;"></td>
													</tr>																																					
												</table>
											</td>
										</tr>						
									</table>
								</td>			
							</tr>
							<tr class="ui-color-contents-style-1">
								<td height="" colspan="4">&nbsp;</td>
							</tr>
							<tr class="ui-color-contents-style-1">
								<td style="padding-left:0px; margin-top:-2px;" width="100%" colspan="4" valign="top">
									<table width="99%" class="ui-content-middle-menu-workorder" style="">
										<tr style="color:white;" height="30px">
											<td colspan="2" class="ui-header-new"><b>Work Order</b></td>
										</tr>
										<tr >
											<td class="ui-desk-style-table">
												<table class="ui-content-form" width="100%" border="0">
													<tr>
														<td style="padding-left:10px;" width="25%">Create Work Order: </td>
														<td style="padding-left:10px;" width="25%"><input class="InputText" type="checkbox" id="" value="ON"  checked></td>
													</tr>																																																													
												</table>
											</td>
										</tr>						
									</table>
								</td>			
							</tr>					
						</table>
					</td>				
				</tr>
			
			<tr class="ui-color-contents-style-1">
				<td height="10px" colspan="4">&nbsp;</td>
			</tr>
			<tr class="ui-color-style-2" style="height:40px;">
				<td align="center" colspan="4" style="border-bottom-left-radius:10px; border-bottom-right-radius:10px;">
					<input type="submit" class="btn-button" name="mysubmit" value="Submit Post!" />
				</td>
			</tr>
		</table>	
	</div>
	</form>
</div>
</body>
</html>
<?php echo form_open('contentcontroller/sys_admin?gbl=3');?>
<?php $numberdate = 0; ?>
<div class="ui-middle-screen">
	<div class="content-workorder">
		<div class="div-p">&nbsp;</div>
		<div class="ui-main-form" style="background:#fff;">
			<div class="ui-main-form-header" style="background:#79B6D8;">
				<table align="left" height="40px" border="0">
					<tr>
						<td><span style="margin-left:10px;"><?php if ($this->input->get('pr') == 'pending') { echo 'PR';}else{ echo 'MIRN' ;} ?> Approval View</span></td>
					</tr>
				</table>
			</div>
			<div class="ui-main-form-1">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
									<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Details</td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">MRIN Reference No.:</td>
											<td>MRIN/MKA/MKA/00535/2016</td>
										</tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">MRIN Date:</td>
											<td valign="top">28 Jun 2016</td>
										</tr>
										<?php if (($this->input->get('pro') == 'approved') or $this->input->get('pro') == 'pending') { ?>
										<tr>
										<td style="padding-left:10px; padding-top:5px;" valign="top">MRIN Procurement Received Date :</td>
										<td valign="top"></td>
										</tr>
										<?php } ?>
										<tr>
											<td style="padding-left:10px;" valign="top">MRIN Requestor :  </td>
											<td>Nur Aishah binti Sulaiman</td>
										</tr>
										<tr>
											<td style="padding-left:10px;" valign="top">MRIN Related Asset : </td>
											<td>BEVEN05-0029 <span class="icon-windows" onclick="fLabour(this)" value="Labour" ></span></td>
										</tr>
										<?php if ($this->input->get('pr') == 'pending') { ?>
										<tr>
										<td style="padding-left:10px; padding-top:5px;" valign="top">MRIN Related Work Order  :</td>
										<td valign="top">HSI/A4/B01742/15 <span class="icon-windows" onclick="fLabour(this)" value="Labour" ></span></td>
										</tr>
										<?php } ?>										
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<div class="ui-main-form-2">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Comments </td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Comments :</td>
											<td><textarea class="input n_com2" name="" readonly></textarea></td>
										</tr>											
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<div class="ui-main-form-5">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Item Specification </td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px; width:70px;" valign="top">Item(s) :</td>
											<td>
												<table class="wnctable" border="1" style="text-align:center;" align="center">
													<tr>
														<th>No</th>
														<th>Item Code</th>
														<th>Item Name</th>
														<?php if($this->input->get('pro') == 'pending'){?>
														<th>Vendor & Price</th>
														<?php } ?>
														<th>Qty Required</th>
														<th><?php  if (($this->input->get('pr') == 'approved') or ($this->input->get('pr') == 'pending')){ echo 'AM'; }?> Qty Approved</th>
														<?php if (($this->input->get('pr') == 'approved') or ($this->input->get('pr') == 'pending')) { ?>
														<th>Procurement <br/> Approved Qty</th>
														<th>Logistic Approved Qty</th>
														<th>Price Per Unit</th>														
														<?php } ?>
													</tr>
													<tr>
														<td>1</td>
														<td><b>SPO2-A00041</b></td>
														<td><b>Ext Cable for Nellcor EC-8/DEC-8 </b></td>
														<?php if($this->input->get('pro') == 'pending'){?>
														<td><b>($)</b></td>
														<?php } ?>
														<td><b>1</b></td>
														<?php if($this->input->get('pro') != 'pending'){?>
														<td><b>1</b></td>
														<?php }else{ ?>
														<td><input type="text" name="" value="" class="form-control-button2 n_wi-date2"></td>
														<?php } ?>
														<?php if (($this->input->get('pr') == 'approved') or ($this->input->get('pr') == 'pending')) { ?>
														<td></td>
														<td>1</td>
														<td>330</td>														
														<?php } ?>
													</tr>
												</table>
											</td>
										</tr>											
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<div class="ui-main-form-1">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Root Cause of Breakdown</td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Complaint / Error / Problem Statement :</td>
											<td><textarea class="input n_com" name="" readonly></textarea></td>
										</tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Root Cause to Faulty Part :</td>
											<td><textarea class="input n_com" name="" readonly></textarea></td>
										</tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Action Taken : <br />i) How? / Why?<br />ii) Effect / Action Taken<br />iii) Solution </td>
											<td><textarea class="input n_com" name="" readonly></textarea></td>
										</tr>										
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<?php if(($this->input->get('pr') == 'pending') or ($this->input->get('pr') == 'approved')){?>
			<div class="ui-main-form-2">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">AM Approval Remark</td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Remark :</td>
											<td><textarea class="input n_com" name="" readonly></textarea></td>
										</tr>									
									</table>
								</td>
							</tr>
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Procurement Approval Remark</td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Remark :</td>
											<td><textarea class="input n_com" name="" readonly></textarea></td>
										</tr>									
									</table>
								</td>
							</tr>
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Logistic Approval Remark</td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Remark :</td>
											<td><textarea class="input n_com" name="" readonly></textarea></td>
										</tr>									
									</table>
								</td>
							</tr>
					</table>
				</div>				
			</div>
			<div class="ui-main-form-5">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="" class="ui-bottom-border-color" style="font-weight: bold;">Purchase Request ( Item Specification ) </td></tr>
										<tr>
											<td>
												<table class="wnctable" border="1" style="text-align:center;" align="center">
													<tr>
														<th>No</th>
														<th>Re./MIRN No</th>
														<th>Description of goods / services</th>
														<th>Vendor</th>
														<th>Price Per Unit</th>
														<th>Qty Required</th>
														<th>Amount</th>
													</tr>
													<tr>
														<td>1</td>
														<td><b>MRIN/SJ/HSI/01352/2015 </b></td>
														<td align="left"><b>PHYSIOLOGIC MONITORING SYSTEMS, ACUTE CARE <br />
																MODEL : Dash 2000<br />
																BRAND : GE marquette<br />
																ASSET NO : BEICM11-0026 </b></td>
														<td><b>PORTABLE ENGINEERING SDN BHD </b></td>
														<td><b>330</b></td>
														<td><b>1</b></td>
														<td><b>330</b></td>														
													</tr>
												</table>
											</td>
										</tr>											
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<?php } ?>
			<div class="ui-main-form-1">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Components & Attachments</td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" class="ui-w">Components :</td>
											<td></td>
										</tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Attachments   :</td>
											<td></td>
										</tr>
										<style>
											.icon{
											 font-size:14px;
											 margin-right:5px;
											 margin-left:5px;
											 color:red;
											 display:iniline-block;
											}
											.icon2{
											 font-size:14px;
											 margin-left:5px;
											 color:green;
											}
										</style>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top" colspan="2"> 
												<ul style="list-style-type: none;">
													<?php if($this->input->get('pro') == 'pending'){?>
													<li><span class="icon-play icon"></span>Root Cause_Cmis_Picture <span class="icon-new icon2"></li>
													<li><span class="icon-play icon"></span>Work Order <span class="icon-new icon2"></li>
													<?php }else{ ?>
													<li><span class="icon-play icon"></span>Root Cause, Cmis, Gambar, Wo  <span class="icon-new icon2"></li>
													<li><span class="icon-play icon"></span>Quotation <span class="icon-new icon2"></li>
													<?php } ?>
												</ul>
											</td>
										</tr>										
									</table>
								</td>
							</tr>
					</table>
				</div>
				<?php if($this->input->get('pr') == 'pending'){?>
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Approval Signature</td></tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px; width:180px;" valign="top">Scan Sign Document :  </td>
											<td style=" text-align:left;"><a href="javascript:void(0)" onclick="fCallLocationa('a')" value="z" ><span class="icon-plus" style="font-size:12px; color:green;" ></span> Add New </a></td>
										</tr>
										<tr style="display:none;" id="display">
											<td style="padding-left:10px;" colspan="2">
												<ul style="list-style-type: none; font-size:16px;">
													<li> <span class="icon-play icon"></span><span id="n_agent"></span><span class="icon-new icon2" id="n_agent2"></span></li>
												</ul>
											</td>
										</tr>										
									</table>
								</td>
							</tr>
					</table>
				</div>
				<?php } ?>
			</div>
			<div class="ui-main-form-2">
				<div class="middle_d">
					<table width="100%" class="ui-content-form-reg" style="">
							<tr >
								<td class="ui-desk-style-table">
									<table class="ui-content-form" width="100%" border="0">
										<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;"><?php if($this->input->get('pr') == 'pending'){ echo 'AM Approval Remark';} elseif ($this->input->get('pr') == 'approved'){ echo 'Procurement ';} else { echo 'SM / HPS ';}?> </td></tr>
										<?php if($this->input->get('pro') == 'pending'){?>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Options  :</td>
											<td>
												<input type="radio" id="radio-1-1" name="n_options" class="regular-radio" value="Approved"  checked="checked"/>   
												<label for="radio-1-1"></label> Approved <span style="display:inline-block; width:15px;"></span>
												<input type="radio" id="radio-1-2" name="n_options" class="regular-radio" value="Reject" />   
												<label for="radio-1-2"></label> Reject <span style="display:inline-block; width:15px;"></span>
												<input type="radio" id="radio-1-3" name="n_options" class="regular-radio" value="Returned" />   
												<label for="radio-1-3"></label> Returned
											</td>
										</tr>
										<?php } ?>
										<?php if($this->input->get('pr') == 'pending'){?>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Options  :</td>
											<td>
												<input type="radio" id="radio-1-1" name="n_options" class="regular-radio" value="Approved"  checked="checked"/>   
												<label for="radio-1-1"></label> Approved <span style="display:inline-block; width:15px;"></span>
												<input type="radio" id="radio-1-2" name="n_options" class="regular-radio" value="Reject" />   
												<label for="radio-1-2"></label> Reject <span style="display:inline-block; width:15px;"></span>
											</td>
										</tr>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Vendor Reference  :</td>
											<td><input type="text" name="" value="" class="form-control-button2" style="width:83%;"></td>
										</tr>
										<?php } ?>
										<?php if($this->input->get('pr') == 'approved'){?>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Options  :</td>
											<td>
												<input type="radio" id="radio-1-1" name="n_options" class="regular-radio" value="Approved"  checked="checked"/>   
												<label for="radio-1-1"></label> Approved <span style="display:inline-block; width:15px;"></span>
												<input type="radio" id="radio-1-2" name="n_options" class="regular-radio" value="Reject" />   
												<label for="radio-1-2"></label> Reject <span style="display:inline-block; width:15px;"></span>
												<input type="radio" id="radio-1-3" name="n_options" class="regular-radio" value="KIV" />   
												<label for="radio-1-3"></label> KIV
											</td>
										</tr>
										<?php } ?>
										<tr>
											<td style="padding-left:10px; padding-top:5px;" valign="top">Remark    :</td>
											<td><textarea class="input n_com" name="" <?php if($this->input->get('pro') != 'pending'){ echo 'readonly';}?>></textarea></td>
										</tr>										
									</table>
								</td>
							</tr>
					</table>
				</div>
			</div>
			<table align="center" height="40px" border="0" style="width:100%;" class="ui-main-form-footer">
				<tr>
					<td align="center">
					<?php if($this->input->get('pro') == 'pending'){?>
					<input type="button" class="btn-button btn-primary-button" style="width: 200px;" name="mysubmit" value="Clear all">
					<input type="submit" class="btn-button btn-primary-button" style="width: 200px;" name="mysubmit" value="Save"> 
					<input type="button" class="btn-button btn-primary-button" style="width: 200px;" onclick="window.history.back()" name="Cancel" value="Cancel">
					<?php }elseif (($this->input->get('pr') == 'approved') or ($this->input->get('pr') == 'pending')){ ?>
					<input type="submit" class="btn-button btn-primary-button" style="width: 200px;" name="mysubmit" value="Save"> 
					<input type="button" class="btn-button btn-primary-button" style="width: 200px;" onclick="window.history.back()" name="Cancel" value="Cancel">
					<?php }else{ ?>
					<input type="button" class="btn-button btn-primary-button" style="width: 200px;" onclick="window.history.back()" name="Cancel" value="Back">
					<?php } ?>
					</td>
				</tr>
			</table>
		</div>
	</div>
</div>
<?php include 'content_jv_popup.php';?>
</body>
<?php echo form_close(); ?>
</html>

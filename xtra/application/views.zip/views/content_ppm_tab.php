
			<tr class="ui-left_web">
				<?= ($this->input->get('ppm') == '0') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px; width:25%;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px; width:25%;">'?>
				<?php echo anchor ('contentcontroller/catalogppm/'.$this->session->userdata('usersess').'?&tab=1&ppm=0'.'&y='.$year.'&m='.$month. '&parent='.$this->input->get('parent'), 'All'); ?></td>
				<?= ($this->input->get('ppm') == '1') ? '<td class="ui-highlight" align="center" colspan="0" style="width:37.5%;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="width:37.5%;">'?>
				<?php echo anchor ('contentcontroller/catalogppm/'.$this->session->userdata('usersess').'?&tab=1&ppm=1'.'&y='.$year.'&m='.$month. '&parent='.$this->input->get('parent'), ' Completed'); ?></td>
				<?= ($this->input->get('ppm') == '2') ? '<td class="ui-highlight" align="center" colspan="0" style="width:37.5%;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="width:37.5%;">'?>
				<?php echo anchor ('contentcontroller/catalogppm/'.$this->session->userdata('usersess').'?&tab=1&ppm=2'.'&y='.$year.'&m='.$month. '&parent='.$this->input->get('parent'), ' Open'); ?></td>
			</tr>

<tr class="ui-middle-color">
	<td class="ui-left_mobile">
<?php
if (!is_null($this->input->get('ppm'))){
	if ($this->input->get('ppm') == 0){ 
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		//echo anchor ('contentcontroller/qap3','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "All";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
 		echo anchor ('contentcontroller/catalogppm/'.$this->session->userdata('usersess').'?&tab=1&ppm=1'.'&y='.$year.'&m='.$month,'<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('ppm') == 1){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/catalogppm/'.$this->session->userdata('usersess').'?&tab=1&ppm=0'.'&y='.$year.'&m='.$month,'<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Completed";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		echo anchor ('contentcontroller/catalogppm/'.$this->session->userdata('usersess').'?&tab=1&ppm=2'.'&y='.$year.'&m='.$month,'<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('ppm') == 2){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/catalogppm/'.$this->session->userdata('usersess').'?&tab=1&ppm=1'.'&y='.$year.'&m='.$month,'<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Open";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		//echo anchor ('contentcontroller/assetworkorder?asstno='.$this->input->get('asstno').'&tab=3','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
}?>
<div class="ui-middle-screen">
	<div class="content-workorder" align="center">
		<table class="ui-content-middle-menu-workorder" border="0" height="" width="95%" align="center">
			<tr class="ui-color-contents-style-1">
				<td colspan="12" height="10px" style="border-top-left-radius:10px; border-top-right-radius:10px;">&nbsp;</td>
			</tr>
			<tr class="ui-color-contents-style-1">
				<td style="padding-left:0px; margin-top:-2px;" width="40%" colspan="12" valign="top">
					<table width="98%" class="ui-content-middle-menu-workorder" style="">
						<tr class="ui-color-contents-style-1" height="30px">
							<td colspan="2" class="ui-header-new"><b>ComplaintDetails</b><span style="float: right; padding-right:10px;"><?php echo anchor ('contentcontroller/deskupdate', '<button type="button" class="btn btn-primary btn-block">Update</button>'); ?></span></td>
						</tr>
						<tr >
							<td class="ui-desk-style-table">
								<table class="ui-content-form" width="100%" border="0">
									<tr><td colspan="3" class="ui-bottom-border-color" style="font-weight: bold;">Complaint Details</td></tr>	
									<tr>
										<td width="100">&nbsp;</td>
										<td width="200">Complaint Number :</td>
										<td>C/B00004/14 </td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>Current Status :</td>
										<td></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>Requested By :</td>
										<td>Cik Nor Baidura</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>Designation :</td>
										<td></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>Complaint Date :</td>
										<td>Oct 16, 2014 16:15</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>Priority :</td>
										<td>Normal</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>Source :</td>
										<td>MOH  </td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>NCR No :</td>
										<td></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>VCM Month :</td>
										<td></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>VCM Year :</td>
										<td>-not applicable-</td>
									</tr>
									<tr>
										<td>&nbsp;</td>
										<td>Summary :</td>
										<td>Laporan teknikal AU480 masih belum dihantar semula  </td>
									</tr>
									<tr><td colspan="3" class="ui-bottom-border-color" style="font-weight: bold;">Location</td></tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Phone Number :</td>
										<td>207 </td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>User Department :</td>
										<td>LAB PATHOLOGY</td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Location :</td>
										<td>LA104</td>
									</tr>
									<tr><td colspan="3" class="ui-bottom-border-color" style="font-weight: bold;">Related Asset</td></tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Asset Number :</td>
										<td>BEANL10-0001 </td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Asset Tag Number :</td>
										<td>AGJ000008</td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Asset Name :</td>
										<td>Analyzers, Laboratory, Clinical Chemistry, Automated, Discrete</td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Serial Number :</td>
										<td>0080380</td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td valign="top">Warranty End Date :</td>
										<td>Dec 02, 2014<br />
											<span style="color:green; font-weight: bold;">Warranty still valid at the time of complaint.</span>
										</td>
									</tr>
									<tr><td colspan="3" class="ui-bottom-border-color" style="font-weight: bold;">Follow Up</td></tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Personnel Code :</td>
										<td></td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Personnel Name :</td>
										<td></td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Designation :</td>
										<td></td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Started On :</td>
										<td></td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td valign="top">Ended On :</td>
										<td></td>
									</tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td valign="top">Action Taken :</td>
										<td></td>
									</tr>
									<tr><td colspan="3" class="ui-bottom-border-color" style="font-weight: bold;">Closing</td></tr>
									<tr style="height:20px;">
										<td>&nbsp;</td>
										<td>Close Date :</td>
										<td></td>
									</tr>																																							
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr class="ui-color-contents-style-1" style="height:10px;">
				<td align="center" colspan="0" style="border-bottom-left-radius:10px; border-bottom-right-radius:10px;">&nbsp;</td>
			</tr>
		</table>
	</div>
</div>
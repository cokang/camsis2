				<div class="tbl-container">
					<table id="tbl-responsive">
						<thead >
							<tr>
								<th>No</th>
								<th>Asset Description</th>
								<th>Aging</th>
								<th>Asset count</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td data-title="No :">1</td>
								<td data-title="Asset Description :">a</td>
								<td data-title="Aging :">d</td>
								<td data-title="Asset count :">a</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</section>
	</div>

</body>
</html>
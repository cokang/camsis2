<body>
	<button type="cancel" class="btn-button btn-primary-button" onclick="window.history.back()" style="width:10%;">Back</button>
	<div class="header_report_main"> DEDUCTION PERFORMANCE REPORT</div>
	<div class="header_drowdown"> 
		<table class="header_drowdown_tbl">
			<tr>
				<td>Deduction Year :</td>
			</tr>
			<tr>
				<td>
					<select name="">
						<option selected value="2014">2014</option>
						<option  value="2015">2015</option>
					</select><input type="submit" value="submit"> </input></td>
					<td>
				</td>
			</tr>
		</table>
	</div>
	<div class="middle_report_main">
		<table class="middle_report_tbl">
			<tr>
				<th colspan="14" class="middle_report_tbl_tr">Deduction Summary</th>
			</tr>
			<tr>
				<th>Services</th>
				<th>Jan</th>
				<th>Feb</th>
				<th>Mar</th>
				<th>Apr</th>
				<th>May</th>
				<th>Jun</th>
				<th>Jul</th>
				<th>Aug</th>
				<th>Sep</th>
				<th>Oct</th>
				<th>Nov</th>
				<th>Dec</th>
				<th>Average</th>
			</tr>
			<tr><td>BES</td><td>2.76%</td><td>1.58%</td><td>1.82%</td><td>0.98%</td><td>1.25%</td><td>1.29%</td><td>1.34%</td><td>1.4%</td><td>0.35%</td><td>1.16%</td><td>1.9%</td><td>2.49%</td><td>1.53%</td></tr>

<tr class="alt"><td>FES</td><td>1.72%</td><td>0.85%</td><td>0.52%</td><td>0.71%</td><td>0.89%</td><td>0.57%</td><td>0.79%</td><td>0.8%</td><td>0.53%</td><td>0.98%</td><td>0.91%</td><td>0.66%</td><td>0.83%</td></tr>
 
<tr><td>HSKP</td><td>1.93%</td><td>1.7%</td><td>2.1%</td><td>1.8%</td><td>2.07%</td><td>1.88%</td><td>0.92%</td><td>0.77%</td><td>1.01%</td><td>0.74%</td><td>1.05%</td><td>1.57%</td><td>1.46%</td></tr>

<tr class="alt"><td>CWA</td><td>1.03%</td><td>1.85%</td><td>1.12%</td><td>0.69%</td><td>0.58%</td><td>0.91%</td><td>0.29%</td><td>0.48%</td><td>0.23%</td><td>0.31%</td><td>1.29%</td><td>1.51%</td><td>0.86%</td></tr>
 
<tr><td>SEC</td><td>0.65%</td><td>0.74%</td><td>0.26%</td><td>0.32%</td><td>0.51%</td><td>0.19%</td><td>0.15%</td><td>0.12%</td><td>0.19%</td><td>0%</td><td>0%</td><td>0%</td><td>0.26%</td></tr>



<tr bgcolor="#F8E0F7"><td>Grand Total</td><td>0.93%</td><td>0.82%</td><td>0.88%</td><td>0.63%</td><td>0.82%</td><td>0.79%</td><td>0.45%</td><td>0.48%</td><td>0.56%</td><td>0.62<td>0.95%</td><td>0.76%</td>
<td>0.72%</td></tr>

		</table>
	</div>
</body>
<html>
<body>
	<button type="cancel" class="btn-button btn-primary-button" onclick="window.history.back()" style="width:10%;">Back</button>
	<div class="header_report_main"> PPM AGEING REPORT</div>
	<div class="middle_report_main">
		<table class="middle_report_tbl">
			<tr>
				<th colspan="10" class="middle_report_tbl_tr">PPM by AGEING</th>
			</tr>
			<tr>
				<th>Services</th>
				<th>1 Months</th>
				<th>2 Months</th>
				<th>3 Months</th>
				<th>4 Months</th>
				<th>5 Months</th>
				<th>6 Months</th>
				<th>7 Months</th>
				<th>8 Months</th>
				<th>Total</th>
			</tr>
			<tr><td>BES</td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=1&h=BPH">2</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=2&h=BPH">1</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=3&h=BPH">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=4&h=BPH">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=5&h=BPH">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=6&h=BPH">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=7&h=BPH">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=8&h=BPH">0</a></td><td>3</td></tr>

<!--<tr class="alt"><td>HSA</td><td>37</td><td>2</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>40</td></tr>-->
<tr class="alt"><td>FES</td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=1&h=HSA">37</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=2&h=HSA">2</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=3&h=HSA">1</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=4&h=HSA">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=5&h=HSA">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=6&h=HSA">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=7&h=HSA">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=8&h=HSA">0</a></td><td>40</td></tr>
 
<!--<tr><td>HSI</td><td>0</td><td>0</td><td>1</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>2</td></tr>-->
<tr><td>HSK</td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=1&h=HSI">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=2&h=HSI">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=3&h=HSI">1</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=4&h=HSI">1</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=5&h=HSI">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=6&h=HSI">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=7&h=HSI">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=8&h=HSI">0</a></td><td>2</td></tr>

<!--<tr class="alt"><td>KLN</td><td>2</td><td>0</td><td>0</td><td>1</td><td>0</td><td>0</td><td>0</td><td>0</td><td>3</td></tr>-->
<tr class="alt"><td>CWA</td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=1&h=KLN">2</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=2&h=KLN">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=3&h=KLN">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=4&h=KLN">1</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=5&h=KLN">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=6&h=KLN">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=7&h=KLN">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=8&h=KLN">0</a></td><td>3</td></tr>
 
<!--<tr><td>KTG</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td><td>0</td></tr>-->
<tr><td>SEC</td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=1&h=KTG">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=2&h=KTG">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=3&h=KTG">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=4&h=KTG">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=5&h=KTG">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=6&h=KTG">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=7&h=KTG">0</a></td><td><a href="reportbi-woppmwrty-listing-dev.asp?m=8&h=KTG">0</a></td><td>0</td></tr>


<tr style="background:#F7F2E0;"><td>Grand Total</td><td>104</td><td>36</td><td>67</td><td>6</td><td>7</td><td>1</td><td>0</td><td>0</td><td>221</td></tr>

		</table>
	</div>
</body>
<html>
<div class="ui-middle-screen">
<div class="ui-left_web"><?php include 'content_web_desk_closed.php';?></div>
<div class="ui-left_mobile"><?php include 'content_mobile_desk_closed.php';?></div>
</div>
</body>
</html>
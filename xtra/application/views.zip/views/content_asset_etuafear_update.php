<div class="ui-middle-screen">
	<div class="content-workorder" align="center">
		<div class="div-p">
		<table class="ui-desk-style-table3" cellpadding="4" cellspacing="0" width="80%">	
			<tr class="ui-color-contents-style-1" height="40px">
				<td class="ui-header-new" colspan="2"><b>Update Condition And Work Acceptance For Equipment / Accessories Returned By Third Party</b></td>
			</tr>
			<tr>
				<td class="p-left" >Name</td>
				<td colspan="">: <input type="text" name="n_Equipment_Name " value="" class="form-control-button2" ></td>
			</tr>
			<tr>
				<td class="p-left">Designation</td>
				<td >: <input type="text" name="n_Equipment_Name " value="" class="form-control-button2" ></td>
			</tr>
			<tr>
				<td class="p-left">Date</td>
				<td>: <input type="date" name="n_Equipment_Name " value="" class="form-control-button2" style="width:32%;"></td>
			</tr>
			<tr class="ui-header-new" style="height:40px;">
				<td align="center" colspan="6">
					<?php echo anchor ('contentcontroller/assetetuafear_confirm', '<button type="button" class="btn-button btn-primary-button" style="width:200px;">Save</button>'); ?>
					<!--<input type="submit" class="btn-button btn-primary-button" style="width:200px;" name="mysubmit" value="Save" />-->
				</td>
			</tr>
		</table>	
		</div>				
	</div>
</div>
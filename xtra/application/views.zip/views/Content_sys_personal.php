<div class="ui-middle-screen">
	<div class="content-workorder">
		<div class="div-p">&nbsp;</div>	
			<div class="ui-main-form-5">
				<div class="middle_d2">
					<table width="100%" class="ui-content-form-reg" style="">
						<tr class="ui-color-contents-style-1" height="30px">
							<td colspan="2" class="ui-header-new">
							<b><span class="textmenu" style="float:left;">Personal</span></b>
							<span class="textmenu1" style="float:right;padding-top:0px;">
							<?php echo anchor ('contentcontroller/sys_admin?gbl=2', '<button type="button" class="btn-button btn-primary-button">Add</button>'); ?>
							</span>
							</td>
						</tr>
						<tr >
							<td class="ui-desk-style-table">
							<table class="ui-content-form" id="no-more-tables" width="100%" border="0">
								<tr>	
									<th width="30px">No</td>
									<th>Personal Code</th>
									<th>Name</th>
									<th>Designation</th>
								</tr>
								<tr align="center" >
									<td data-title="No :">1</td>
									<td data-title="Personal Code :"><?php echo anchor ('contentcontroller/sys_admin?gbl=2&sys_id=APSB280','APSB280');?></td>
									<td data-title="Name :">Noor Razimy Bin Mokhtar</td>
									<td data-title="Designation :">Engineer</td>
								</tr>
								<tr align="center" >
									<td data-title="No :">2</td>
									<td data-title="Personal Code :"><?php echo anchor ('contentcontroller/sys_admin?gbl=2&sys_id=APSB290','APSB290');?></td>
									<td data-title="Name :">Mohd Noraswadi Bin Mohamad</td>
									<td data-title="Designation :">Engineer</td>
								</tr>
								<tr align="center" >
									<td data-title="No :">3</td>
									<td data-title="Personal Code :"><?php echo anchor ('contentcontroller/sys_admin?gbl=2&sys_id=APSB309','APSB309');?></td>
									<td data-title="Name :">Mohd Norfaizal bin Misman</td>
									<td data-title="Designation :">Assistant Engineer</td>
								</tr>		
							</table>
							</td>
						</tr>
					</table>
				</div>
			</div>
	</div>
</div>
</body>
</html>

<body style="margin:0px;">
<table class="tftable" border="1" style="text-align:center;">
	<tr>
		<th colspan="3">LABOUR GRADE</th>
	</tr>
	<tr align="center">
		<th >No</th>
		<th >Code  </th>
		<th >Description  </th>
	</tr>
	<tr align="center">
		<td style="width:20px;">1</a></td>
		<td><a href="javascript:Setasset('FSE-DLV','Electrical Power Distribution - LV')" >FSE-DLV</a></td>
		<td><a href="javascript:Setasset('FSE-DLV','Electrical Power Distribution - LV')" >Electrical Power Distribution - LV</a></td>
	</tr>
</table>
<script type="text/javascript">
    function Setasset(a_agent,a_agent2) {
        if (window.opener != null && !window.opener.closed) {
            var a_ag = window.opener.document.getElementById("n_s_Code");
            a_ag.value = a_agent;
            var a_ag2 = window.opener.document.getElementById("n_s_Code2");
            a_ag2.value = a_agent2;
        }
        window.close();
    }
</script>
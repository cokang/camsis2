<div class="div-p"></div>
<div class="main-box">
	<div class="box4">
		<div class="small-box bg-purple">
			<div class="inner2" >
				<p>SIQ</p>
			</div>
			<div class="icon"><i class="icon-file-text2"></i></div>
			<?php echo anchor ('contentcontroller/qap3/'.$this->session->userdata('usersess'). '?&tab=0','<span class="ui-left_web">More Info <i class="icon-arrow-right"></i></span>','class="small-box-footer"'); ?>
		</div>
	</div>
	<div class="ui-left_mobile">
		<div class="box4">
		<div class="small-box bg-fuchsia">
			<div class="inner2" >
				<p>Analysis</p>
			</div>
			<div class="icon"><i class="icon-file-text2"></i></div>
			<?php echo anchor ('contentcontroller/qap3_analysisv4/'.$this->session->userdata('usersess'). '?&tab=3','<span class="ui-left_web">More Info <i class="icon-arrow-right"></i></span>','class="small-box-footer"'); ?>
		</div>
	</div>
	<div class="box4">
		<div class="small-box bg-olive">
			<div class="inner2" >
				<p>Report</p>
			</div>
			<div class="icon"><i class="icon-stats-bars"></i></div>
			<?php echo anchor ('contentcontroller/qap3_analysisv4x/'.$this->session->userdata('usersess'). '?&tab=4','<span class="ui-left_web">More Info <i class="icon-arrow-right"></i></span>','class="small-box-footer"'); ?>
		</div>
	</div>
	</div>
	<div class="box3">
		<div class="small-box bg-fuchsia">
			<div class="inner2" >
				<p>Assets Evaluation</p>
			</div>
			<div class="icon"><i class="icon-file-text2"></i></div>
			<?php echo anchor ('contentcontroller/qap3_asset/'.$this->session->userdata('usersess'). '?&tab=1','<span class="ui-left_web">More Info <i class="icon-arrow-right"></i></span>','class="small-box-footer"'); ?>
		</div>
	</div>
	<div class="box3">
		<div class="small-box bg-olive">
			<div class="inner2" >
				<p>Work Order Evaluation</p>
			</div>
			<div class="icon"><i class="icon-stats-bars"></i></div>
			<?php echo anchor ('contentcontroller/qap3_wo/'.$this->session->userdata('usersess'). '?&tab=2','<span class="ui-left_web">More Info <i class="icon-arrow-right"></i></span>','class="small-box-footer"'); ?>
		</div>
	</div>
	<div class="box3 ui-left_web">
		<div class="small-box bg-fuchsia">
			<div class="inner2" >
				<p>Analysis</p>
			</div>
			<div class="icon"><i class="icon-file-text2"></i></div>
			<?php echo anchor ('contentcontroller/qap3_analysisv4/'.$this->session->userdata('usersess'). '?&tab=3','<span class="ui-left_web">More Info <i class="icon-arrow-right"></i></span>','class="small-box-footer"'); ?>
		</div>
	</div>
	<div class="box3 ui-left_web">
		<div class="small-box bg-olive">
			<div class="inner2" >
				<p>Report</p>
			</div>
			<div class="icon"><i class="icon-stats-bars"></i></div>
			<?php echo anchor ('contentcontroller/qap3_analysisv4x/'.$this->session->userdata('usersess'). '?&tab=4','<span class="ui-left_web">More Info <i class="icon-arrow-right"></i></span>','class="small-box-footer"'); ?>
		</div>
	</div>
</div>
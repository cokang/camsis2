<html>
<head>
<link href="<?php echo base_url(); ?>css/style.css" rel="stylesheet" type="text/css" media="all"/>
<link href="<?php echo base_url(); ?>css/jquery-ui.css" rel="stylesheet" type="text/css" media="all"/>
<link href="<?php echo base_url(); ?>css/nav.css" rel="stylesheet" type="text/css" media="all"/>
<link rel="stylesheet" type='text/css' media='all' href="<?php echo base_url().'icon/style.css' ?>">
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/login.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/time.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-1.10.2.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>js/jquery-ui.js"></script>
<!--<script type="text/javascript" src="<?php echo base_url(); ?>js/display.js"></script>-->
</head>
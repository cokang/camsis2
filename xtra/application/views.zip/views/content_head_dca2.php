		<table class="tbl-wo" border="1" align="center" style="border: 1px solid black;">
			<tr>
				<td style="padding-left:50px; width:160px;"><img src="<?php echo base_url(); ?>images/penmedic2.png" style="width:100px; height:40px;"/></td>
				<td>
					<table class="tbl-wo" border="0" align="center">
						<tr>
							<td align="center"><b>AP HOUSEKEEPING SERVICES </b></td>
						</tr>
						<tr>
							<td align="center"><b>IIUM HOSPITAL</b> </td>
						</tr>
						<tr>
							<td align="center"><b>JOINT INSPECTION CHECKLIST</b></td>
						</tr>
					</table>
				</td>
				<!--<td style="padding-left:5px; width:160px;"> 
					<table class="tbl-wo" border="0" align="left">
						<tr>
							<td align="left"> Form No :</td>
						</tr>
						<tr>
							<td align="left"> Version :</td>
						</tr>
						<tr>
							<td align="left"> Date :</td>
						</tr>
					</table>
				</td>-->
				<td style="padding-left:5px; width:160px;"><img src="<?php echo base_url(); ?>images/logo.png" style="width:145px; height:60px;"/></td>
			</tr>
		</table>
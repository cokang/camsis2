<tr class="ui-left_web">
	<td style="height:20px;"></td>
</tr>
<tr class="ui-left_web">
			
		<?= ($this->input->get('vppm') == '0') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php echo anchor ('contentcontroller/wo?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=0', 'Work Order'); ?></td>
		

		<?php  // echo ($this->input->get('vppm') == '1') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php  // echo anchor ('contentcontroller/visitone?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=1', 'Visit One'); ?><!--</td>-->



		<?php  // echo ($this->input->get('vppm') == '2') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php  // echo anchor ('contentcontroller/visittwo?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=2', 'Visit Two'); ?><!--</td>-->


		<?php  // echo ($this->input->get('vppm') == '3') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php  // echo anchor ('contentcontroller/visitthree?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=3', 'Visit Three'); ?><!--</td>-->


		<?= ($this->input->get('vppm') == '4') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php echo anchor ('contentcontroller/visitplus?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=4', 'Visit +'); ?></td>


		<?= ($this->input->get('vppm') == '5') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php echo anchor ('contentcontroller/personnelinvolved?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=5', 'Personnel Involved'); ?></td>




		<?= ($this->input->get('vppm') == '7') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php echo anchor ('contentcontroller/tech?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=7', 'Technical Summary'); ?></td>

		<?= ($this->input->get('vppm') == '8') ? '<td class="ui-highlight" align="center" colspan="0" style="height:30px;">' : '<td class="ui-content-menu-desk-color" align="center" colspan="0" style="height:30px;">' ?>
		<?php echo anchor ('contentcontroller/clau?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=8', 'Clause'); ?></td>
</tr>
<tr class="ui-middle-color">
	<td class="ui-left_mobile">
<?php
if (!is_null($this->input->get('vppm'))){
	if ($this->input->get('vppm') == 0){ 
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		//echo anchor ('contentcontroller/qap3','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Work Order";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
 		echo anchor ('contentcontroller/visitone?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=1','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('vppm') == 1){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/wo?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=0','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Visit One";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		echo anchor ('contentcontroller/visittwo?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=2','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('vppm') == 2){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/visitone?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=1','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Visit Two";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		echo anchor ('contentcontroller/visitthree?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=3','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('vppm') == 3){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/visittwo?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=2','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Visit Three";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		echo anchor ('contentcontroller/personnelinvolved?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=4','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('vppm') == 4){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/visitthree?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=3','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Personnel Involved";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		echo anchor ('contentcontroller/jobclose?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=5','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('vppm') == 5){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/personnelinvolved?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=4','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Job Close";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		echo anchor ('contentcontroller/tech?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=6','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('vppm') == 6){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/jobclose?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=5','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Technical Summary";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		echo anchor ('contentcontroller/clau?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=7','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
	elseif($this->input->get('vppm') == 7){
		echo "<table class='ui-mobile-content-header' border='0' align='center'>";
		echo "<tr>";
		echo "<td style='width:20px;'>";
		echo anchor ('contentcontroller/tech?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=6','<span class="icon-arrow-left"></span>');
		echo "</td>";
		echo "<td align='center'>";
		echo "Clause";
		echo"</td>";
		echo "<td align='right' style='width:20px;'>";
		//echo anchor ('contentcontroller/tech?wrk_ord='.$this->input->get('wrk_ord'). '&vppm=6','<span class="icon-arrow-right"></span>');
		echo "</td>"; 
		echo "</tr>";
		echo "</table>";
	}
}
?>
</td>
</tr>
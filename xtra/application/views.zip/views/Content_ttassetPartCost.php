				<div class="tbl-container">
					<table id="tbl-responsive">
						<thead>
							<tr>
								<th>No</th>
								<th>Asset Description</th>
								<th>Cumulative Part Cost</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td data-title="No :">1</td>
								<td data-title="Asset Description :">test</td>
								<td data-title="Cumulative Part Cost :">test</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</section>
	</div>

</body>
</html>
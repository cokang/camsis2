<body style="margin:0px;">
<table class="tftable" border="1" style="text-align:center;">
    <tr>
        <th colspan="6">Choose Files</th>
    </tr>
    <tr align="center">
        <tr align="center">

            <form enctype="multipart/form-data" action="" method="post">
            <td> <input type="file" class="form-control" name="userFiles" multiple/></td>
            <td> <input class="btn-button btn-primary-button" type="submit" name="fileSubmit" value="UPLOAD"/></td>
            </form>
        </tr>
    </tr>
    
</table>
</body>
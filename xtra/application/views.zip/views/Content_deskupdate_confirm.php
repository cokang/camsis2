<div class="ui-middle-screen">
	<div class="content-workorder" align="center">
		<table width="80%" class="ui-content-middle-menu-workorder" border="0" style=" border-radius:2px solid #398074;" >
			<tr class="ui-color-contents-style-1" height="30px">
				<td colspan="2" class="ui-header-new" style=""><b>UpdateComplaint</b></td>
			</tr>
			<tr class="ui-content-form-2" style="width: 10%;">
				<td class="ui-desk-style-table" width="50%" valign="top">
					<table class="" width="100%" border="0"  height="100%" style="color:black;">
						<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Details</td></tr>	
						<tr>
							<td style="padding-left:10px;" width="50%" height="20px">Complaint Number : </td>
							<td style="padding-left:10px;" width="50%" height="20px"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Requested By :  </td>
							<td style="padding-left:10px;" height="20px"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top" height="20px">Designation : </td>
							<td style="padding-left:10px;" valign="top" height="20px"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top" height="20px">Complaint Date : </td>
							<td style="padding-left:10px;" height="20px"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top" height="20px">Complaint Date : </td>
							<td style="padding-left:10px;" height="20px"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top" height="20px">Priority :  </td>
							<td style="padding-left:10px;" valign="top" height="20px"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top">Source :  </td>
							<td style="padding-left:10px;" valign="top"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top">NCR No : </td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top">VCM Month :  </td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top">VCM Year :   </td>
						</tr>	
						<tr>
							<td style="padding-left:10px;" valign="top">Summary : </td>
							<td style="padding-left:10px;"><textarea class="InputText" name="V_summary" cols="25" rows="5" disabled></textarea></td>
						</tr>	
						<tr>
							<td style="padding-left:10px;" valign="top">Description : </td>
							<td style="padding-left:10px;"><textarea class="InputText" name="V_details" cols="25" rows="5" disabled></textarea></td>
						</tr>
					</table>
				</td>
				<td class="ui-desk-style-table" valign="top">
					<table style="color:black;" width="100%" border="0">
						<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Details of Related Request</td></tr>	
						<tr>
							<td style="padding-left:10px;" width="50%">Request Number : </td>
							<td style="padding-left:10px;" width="50%"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Request Status :  </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Requested By : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Designation : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Requested On : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Priority : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top">Summary : </td>
							<td style="padding-left:10px;"><textarea class="InputText" name="" cols="22" rows="5" disabled></textarea></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Asset Number :  </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Asset Tag Number : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Asset Serial Number : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Asset Name : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Phone Number : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">User Department : </td>
							<td style="padding-left:10px;"></td>
						</tr>	
						<tr>
							<td style="padding-left:10px;">Location :  </td>
							<td style="padding-left:10px;"></td>
						</tr>	
						<tr>
							<td style="padding-left:10px;">Request Closed On : </td>
							<td style="padding-left:10px;"></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr class="ui-content-form-2">
				<td class="ui-desk-style-table" colspan="2">
					<table  width="100%" border="0" style="color:black;">
						<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Location</td></tr>		
						<tr>
							<td style="padding-left:10px;" width="25%">Phone Number :  </td>
							<td style="padding-left:10px;" width=""></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">User Department :   </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">&nbsp; </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Location : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">&nbsp; </td>
							<td style="padding-left:10px;"></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr class="ui-content-form-2">
				<td class="ui-desk-style-table" colspan="2">
					<table  width="100%" border="0" style="color:black;">
						<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Related Asset</td></tr>		
						<tr>
							<td style="padding-left:10px;" width="25%">Asset Number :  </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Asset Tag Number : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Asset Name : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Asset Serial Number : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Warranty Expiry Date :  </td>
							<td style="padding-left:10px;"></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr class="ui-content-form-2">
				<td class="ui-desk-style-table" colspan="2">
					<table  width="100%" border="0" style="color:black;">
						<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Follow Up Information</td></tr>		
						<tr>
							<td style="padding-left:10px;" width="25%">Personnel Code :   </td>
							<td style="padding-left:10px;" ></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Personnel Name :   </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Designation :  </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Start Date : </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">Start  Time :   </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;">End Date :   </td>
							<td style="padding-left:10px;"></td>
						</tr>	
						<tr>
							<td style="padding-left:10px;">End Time :   </td>
							<td style="padding-left:10px;"></td>
						</tr>
						<tr>
							<td style="padding-left:10px;" valign="top">Action Taken :  </td>
							<td style="padding-left:10px;"><textarea class="InputText" name="" cols="25" rows="5" disabled></textarea></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr class="ui-content-form-2">
				<td class="ui-desk-style-table" colspan="2">
					<table  width="100%" border="0" style="color:black;">
						<tr><td colspan="2" class="ui-bottom-border-color" style="font-weight: bold;">Closing</td></tr>		
						<tr>
							<td style="padding-left:10px;" width="25%">Close Date :    </td>
							<td style="padding-left:10px;"></td>
						</tr>
					</table>
				</td>
			</tr>
			<tr class="ui-header-new" style="height:40px;" style="">
				<td align="center" colspan="2" style="border-bottom-left-radius:10px; border-bottom-right-radius:10px;">
					<button type="button">Save</button>
				</td>
			</tr>
		</table>
	</div>	
</div>
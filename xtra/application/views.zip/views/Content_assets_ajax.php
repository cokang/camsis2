<div style="padding-left:50px;">
						<table id="BEANL03" style="display:none; margin:10px;" border="0" class="ui-content-middle-menu-workorder" width="98%">
							<tr class="">
								<td class=""colspan="" style="" valign="top" height="25px">
									<table class="ui-content-middle-menu-workorder2" width="100%" height="25px">
										<tr class="ui-menu-color-header" style="color:white;">
											<td width="5%" style="border-top-left-radius:5px; ">No</td>
											<td width="5%">Asset Number</td>
											<td width="5%">Tag No</td>
											<td width="10%">Asset Name</td>
											<td width="5%">User<br />Dept</td>
											<td width="5%">Location</td>
											<td width="5%">Criticality</td>
											<td width="5%">Condition</td>
											<td width="5%">Status</td>
											<td width="5%">Model</td>
											<td width="5%">Manufacturer</td>
											<td width="5%">Serial no</td>
											<td width="5%" style="border-top-right-radius:5px;">Purchase <br />Cost</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr class="">
								<td class=""colspan="" style="" valign="top" height="25px">
									<table class="ui-content-middle-menu-workorder2" width="100%" height="25px" border="0">
										<tr class="" style="color:black;">
											<td width="5%" style="border-top-left-radius:5px; ">No</td>
											<td width="5%">alohas</td>
											<td width="5%">Tag No</td>
											<td width="10%">Asset Name</td>
											<td width="5%">User Dept</td>
											<td width="5%">Location</td>
											<td width="5%">Criticality</td>
											<td width="5%">Condition</td>
											<td width="5%">Status</td>
											<td width="5%">Model</td>
											<td width="5%">Manufacturer</td>
											<td width="5%">Serial no</td>
											<td width="5%" style="border-top-right-radius:5px;">Purchase <br />Cost</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</div>
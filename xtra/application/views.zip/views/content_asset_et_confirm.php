<div class="ui-middle-screen">
	<div class="content-workorder" align="center">
		<div class="div-p">
		<table class="ui-desk-style-table3" cellpadding="4" cellspacing="0" width="80%">	
			<tr class="ui-color-contents-style-1" height="40px">
				<td class="ui-header-new" colspan="6"><b>Confirm Equipment Transfer Form</b></td>
			</tr>
			<tr>
				<td class="p-left">SERVICE TYPE </td>
				<td class="p-left">: <input type="checkbox" id="" value="ON" Disabled> FES 
				<td class="p-left"> <input type="checkbox" id="" value="ON"  Disabled> BES </td>
			</tr>
			<tr>
				<td class="p-left">ASSET BELONG TO </td>
				<td class="p-left">: <input type="checkbox" id="" value="ON" Disabled> IIUM 
				<td class="p-left"> <input type="checkbox" id="" value="ON" Disabled> APSB </td>
				<td class=""> <input type="checkbox" id="" value="ON" Disabled> OTHERS </td>
				<td style="padding-left:10px;" width="20%" valign="">Reference No : <input type="text" name="n_Refence_No" value="" class="form-control-button2" style="width:100px;" Disabled> </td>
			</tr>
			<tr >
				<td class="ui-desk-style-table2" colspan="5" style="padding-left:3px;">
					<table style="color:black;" width="100%" border="0">	
						<tr>
							<td  style="width:50%;" valign="top">
								<table width="100%" style="color:black;">
									<tr>
										<td style="width:40.8%;">Equipment Name </td>
										<td>: <input type="text" name="n_Equipment_Name " value="" class="form-control-button2" Disabled></td>
									</tr>
									<tr>
										<td style="width:40.8%;">Asset Tag</td>
										<td>: <input type="text" name="n_Asset_Tag" value="" class="form-control-button2" Disabled></td>
									</tr>
									<tr>
										<td style="width:40.8%;">User Dept </td>
										<td>: <input type="text" name="n_User_Dept" value="" class="form-control-button2" Disabled></td>
									</tr>
									<tr>
										<td style="width:40.8%;">Detail of Detect</td>
										<td>: <input type="text" name="n_Detail" value="" class="form-control-button2" Disabled></td>
									</tr>
								</table>
							</td>
							<td class="p-left" style="width:50%;" valign="top">
								<table width="100%" style="color:black;">
									<tr>
										<td style="width:40%;">Work Order No </td>
										<td>: <input type="text" name="n_work_order_no" value="" class="form-control-button2" Disabled></td>
									</tr>
									<tr>
										<td style="width:40%;">Serial No </td>
										<td>: <input type="text" name="n_Serial_No" value="" class="form-control-button2" Disabled></td>
									</tr>
									<tr>
										<td style="width:40%;">User Location </td>
										<td>: <input type="text" name="n_User_Location" value="" class="form-control-button2" Disabled></td>
									</tr>
									<tr>
										<td style="width:40%;">Physial Condition </td>
										<td>:  <input type="checkbox" id="" value="ON"  > Good <input type="checkbox" id="" value="ON"  Disabled> Not Good</td>
									</tr>
									<tr>
										<td style="width:40%;">Remarks </td>
										<td>: <input type="text" name="n_Remarks" value="" class="form-control-button2" Disabled></td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr>
				<td class="p-left">Equipment Taken </td>
				<td class="p-left" colspan="4">: <input type="checkbox" id="" value="ON" Disabled> Without accessory <input type="checkbox" id="" value="ON"  Disabled> With accessory  <input type="checkbox" id="" value="ON"  Disabled> Accessory only </td>
			<tr>
				<td class="p-left" valign="top"><i>Please specity</i></td>
				<td class="p-left" colspan="4" valign="top"> :<textarea class="Input" name="n_Please_specity"  cols="37" rows="3" Disabled> </textarea></td>
			</tr>
			<tr>
				<td colspan="6" height="10px">&nbsp;</td>
			</tr>
			<tr><td colspan="6" class="ui-bottom-border-color" style="font-weight: bold;">Taken By</td></tr>	
			<tr>
				<td class="p-left">Name</td>
				<td class="p-left" colspan="4">: <input type="text" name="n_name" value="" class="form-control-button2" Disabled></td>
			</tr>
			<tr>
				<td class="p-left">Designation</td>
				<td class="p-left" colspan="4">: <input type="text" name="n_Designation" value="" class="form-control-button2" Disabled></td>
			</tr>
			<tr>
				<td class="p-left">Date</td>
				<td class="p-left" colspan="4">: <input type="date" name="n_date" value="" class="form-control-button2" style="width:33%;" Disabled></td>
			</tr>
			<tr><td colspan="6" class="ui-bottom-border-color" style="font-weight: bold;">User Acknowledgment</td></tr>	
			<tr>
				<td class="p-left">Name</td>
				<td class="p-left" colspan="4">: <input type="text" name="n_name" value="" class="form-control-button2" Disabled></td>
			</tr>
			<tr>
				<td class="p-left">Designation</td>
				<td class="p-left" colspan="4">: <input type="text" name="n_Designation" value="" class="form-control-button2" Disabled></td>
			</tr>
			<tr>
				<td class="p-left">Date</td>
				<td class="p-left" colspan="4">: <input type="date" name="n_date" value="" class="form-control-button2" style="width:33%;" Disabled></td>
			</tr>
			<tr><td colspan="6" class="ui-bottom-border-color" style="font-weight: bold;">Guard Acknowledgement For Equipment Out From Hospital</td></tr>
			<tr>
				<td class="p-left">Name</td>
				<td class="p-left" colspan="4">: <input type="text" name="n_name" value="" class="form-control-button2" Disabled></td>
			</tr>
			<tr>
				<td class="p-left">Designation</td>
				<td class="p-left" colspan="4">: <input type="text" name="n_Designation" value="" class="form-control-button2" Disabled></td>
			</tr>
			<tr>
				<td class="p-left">Date</td>
				<td class="p-left" colspan="4">: <input type="date" name="n_date" value="" class="form-control-button2" style="width:33%;" Disabled></td>
			</tr>
			<tr class="ui-header-new" style="height:40px;">
				<td align="center" colspan="6">
					<?php echo anchor ('contentcontroller/assetet_confirm', '<button type="button" class="btn-button btn-primary-button" style="width:200px;">Confirm</button>'); ?>
					<!--<input type="submit" class="btn-button btn-primary-button" style="width:200px;" name="mysubmit" value="Save" />-->
				</td>
			</tr>
		</table>	
		</div>				
	</div>
</div>
<div class="ui-middle-screen">
	<div class="content-workorder" align="center">
		<table class="ui-content-middle-menu-workorder" border="0" height="" width="95%" align="center">
			<?php include 'content_asset_tab.php';?>
			<tr class="ui-color-contents-style-1">
				<td colspan="12" height="20px">&nbsp;</td>
			</tr>
			<tr class="ui-color-contents-style-1">
				<td style="padding-left:0px; margin-top:-2px;" width="40%" colspan="12" valign="top">
					<table width="98%" class="ui-content-middle-menu-workorder" style="">
						<tr class="ui-color-contents-style-1" height="30px">
							<td colspan="2" class="ui-header-new" style="height:37px;" valign="middle"><span style="float: left; margin-top:3px; font-weight: bold;">Maintenance Specification</span></td>
						</tr>
						<tr >
							<td class="ui-desk-style-table" height="200px" align="center">
								<span style="color:red;">THIS SECTION HAS BEEN MOVED TO GENERAL INFO TAB.  <br /> <span style="font-size:14px;">CLICK HERE TO GO THE NEW LOCATION.</span></span>
							</td>
						</tr>
					</table>
				</td>
			</tr>
			<tr class="ui-color-contents-style-1" style="height:10px;">
				<td align="center" colspan="12">&nbsp;</td>
			</tr>
		</table>
	</div>
</div>
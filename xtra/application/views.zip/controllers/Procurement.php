<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Procurement extends CI_Controller {
	public function index(){

		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("head");
		$this ->load->view("left");
		if ($this->input->get('pro') == 'mrin'){ 
		$this ->load->view("Content_mrin",$data);
		}elseif ($this->input->get('pro') == 'approved'){ 
		$this ->load->view("Content_mrin_procure",$data);
		}elseif ($this->input->get('pro') == 'pending'){ 
		$this ->load->view("Content_mrin_procure",$data);
		}elseif ($this->input->get('pro') == 'new'){ 
		$this ->load->view("Content_mrin_new");
		}
	}
	public function asset3_comm_new(){
		$this ->load->view("head");
		$this ->load->view("asset3_comm_new");
	}
	public function e_pr(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("head");
		$this ->load->view("left");
		if ($this->input->get('pr') == 'pending'){ 
		$this ->load->view("Content_mrin_procure",$data);
		}elseif ($this->input->get('pr') == 'approved'){ 
		$this ->load->view("Content_mrin_procure",$data);
		}else{
		$this ->load->view("asset3_e_pr", $data);
		}
	}
	public function e_po_print(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("headprinter");
		$this ->load->view("e_po_print", $data);
	}
	public function report(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("head");
		$this ->load->view("left");
		if ($this->input->get('pr') == 'pending'){ 
		$this ->load->view("Content_mrin_procure",$data);
		}elseif ($this->input->get('pr') == 'approved'){ 
		$this ->load->view("Content_mrin_procure",$data);
		}else{
		$this ->load->view("asset3_report_pro", $data);
		}
	}
	public function pr_report(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("headprinter");
		if ($this->input->get('pr') == 'rs'){ 
		$this ->load->view("Content_rs_report_print",$data);
		}elseif ($this->input->get('pr') == 'vc'){ 
		$this ->load->view("Content_vc_report_print",$data);
		}elseif ($this->input->get('pr') == 'vr'){ 
		$this ->load->view("Content_vr_report_print",$data);
		}
	}
	public function e_request(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("head");
		$this ->load->view("left");
		$this ->load->view("Content_e_request",$data);
	}
	public function po_follow_up2(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("head");
		$this ->load->view("left");
		if  ($this->input->get('po') == 'update') {
		$this ->load->view("Content_po_follow_up2_update",$data);
		}elseif ($this->input->get('po') == 'confirm'){ 
		$this ->load->view("Content_po_follow_up2_update",$data);
		}else{
		$this ->load->view("Content_po_follow_up2",$data);
		}
	}
	public function assetdetailname(){
		$this->load->model("display_model");
		$data['records'] = $this->display_model->list_personel();
		$this ->load->view("head");
		$this ->load->view("content_detail_name",$data);
	}
	public function pro_catalog(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("head");
		$this ->load->view("left");
		$this ->load->view("Content_pro_catalog",$data);
	}
	public function update_delete(){
		$this ->load->view("head");
		$this ->load->view("content_update_delete_vendor");
	}
	public function Release_note(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("head");
		$this ->load->view("left");
		if  ($this->input->get('pro') == 'new') {
		$this ->load->view("Content_Release_note_newedit",$data);
		}elseif ($this->input->get('pro') == 'edit'){ 
		$this ->load->view("Content_Release_note_newedit",$data);
		}else{
		$this ->load->view("Content_Release_note",$data);
		}
	}
	public function report_progress(){
		$data['year']= ($this->input->get('y') <> 0) ? $this->input->get('y') : date("Y");	
		$data['month']= ($this->input->get('m') <> 0) ? sprintf("%02d", $this->input->get('m')) : date("m");
		$this ->load->view("headprinter");
		$this ->load->view("content_report_progress",$data);
	}
}
?>
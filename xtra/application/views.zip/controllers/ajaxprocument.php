<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ajaxprocument extends CI_Controller {
	public function index(){
	if ($this->uri->slash_segment(1) == 'Procurement/') {
	 $jvtable = "update_delete";
	}
	else {
		 $jvtable = "update_delete";
		
	}
		echo "<script language=\"javascript\"> function fLabour(a){
			winProp = 'width=600,height=400,left=' + ((screen.width - 600) / 2) +',top=' + ((screen.height - 400) / 2) + ',menubar=no, directories=no, location=no, scrollbars=yes, statusbar=no, toolbar=no, resizable=no';
			Win = window.open('".$jvtable."?tab='+a, '', winProp);
			Win.window.focus();
		}</script>";
		//$this->load->model("get_model");
		//$data['asset_det'] = trim($this->input->get('ast'));
		echo '<table class="ui-content-middle-menu-workorder3" width="100%" id="no-more-tables"><tr class="ui-menu-color-header" style="color:white; font-weight:bold;"><th>No</th><th style="width:40%;">Vendor Details</th><th style="width:20%;">Vendor Item Id</th><th style="width:20%;">Price (RM)</th></tr>';
		$i = 1;
		//echo trim($this->input->get('ast'));
		//print_r(trim($this->input->get('ast')));
		//$result = array_map('trim', $data['asset_det']);
		//print_r($result);
		//exit();
			echo "<tr style='color:black;' align='center'>";
			echo '<td data-title="No :">'.$i++.'</td>';
			echo '<td data-title="Vendor Details :">PORTABLE ENGINEERING SDN BHD</td>';
			echo '<td data-title="Vendor Item Id :">N/A</td>';
			echo '<td data-title="Price (RM):">8 </td>';
?>
			<td data-title=""><a href="javascript:void(0);" onclick="fLabour('Delete');"><span style="color:red; font-size:12px;" class="icon-cross"></span> Delete </a></td>
			<td data-title=""><a href="javascript:void(0);" onclick="fLabour('Update');"><span style="color:green; font-size:12px;" class="icon-new"></span> Update </a></td>
			
<?php
			echo '</tr>';
			echo '</table>';
	}
}
?>
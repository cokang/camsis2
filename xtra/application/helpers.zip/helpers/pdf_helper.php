<?php 
	function tcpdf()
	{
		require_once('tcpdf/config/tcpdf_config.php');
		require_once('tcpdf/tcpdf.php');
	}
?>